<script>
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  
  // Props for customization
  export let menuItems = [
    { href: '/', label: 'Home' },
    { href: '/events', label: 'Events' },
    { href: '/gallery', label: 'Gallery' },
    { href: '/about', label: 'About' },
    { href: '/contact', label: 'Contact' },
    { href: '/language/amharic', label: 'አማርኛ' }
  ];
  
  export let logoText = 'Enkutatashi';
  export let logoHref = '/';
  export let primaryColor = 'yellow-400';
  export let textColor = 'gray-800';
  
  let mobileMenuOpen = false;
  
  function toggleMobileMenu() {
    mobileMenuOpen = !mobileMenuOpen;
  }
  
  onMount(() => {
    // Close mobile menu when clicking outside
    const handleClickOutside = (event) => {
      const mobileMenu = document.getElementById('mobile-menu');
      const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
      
      if (mobileMenuOpen && mobileMenu && !mobileMenu.contains(event.target) && 
          mobileMenuToggle && !mobileMenuToggle.contains(event.target)) {
        mobileMenuOpen = false;
      }
    };
    
    document.addEventListener('click', handleClickOutside);
    
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  });
</script>

<!-- Mobile Navigation -->
<div class="md:hidden">
  <!-- Mobile Hamburger Button -->
  <button 
    id="mobile-menu-toggle"
    class="fixed top-4 right-4 z-50 flex flex-col justify-center items-center w-12 h-12 bg-{primaryColor} rounded-full shadow-lg focus:outline-none" 
    on:click={toggleMobileMenu}
    aria-label="Toggle mobile menu"
  >
    <span class="block w-6 h-0.5 bg-{textColor} rounded-sm my-0.5 transition-all duration-300" class:rotate-45={mobileMenuOpen} class:translate-y-[6px]={mobileMenuOpen}></span>
    <span class="block w-6 h-0.5 bg-{textColor} rounded-sm my-0.5 transition-all duration-300" class:opacity-0={mobileMenuOpen}></span>
    <span class="block w-6 h-0.5 bg-{textColor} rounded-sm my-0.5 transition-all duration-300" class:-rotate-45={mobileMenuOpen} class:-translate-y-[6px]={mobileMenuOpen}></span>
  </button>
  
  <!-- Mobile Menu -->
  <div 
    id="mobile-menu"
    class="fixed top-0 w-4/5 max-w-xs h-full bg-white z-40 shadow-lg transition-all duration-300 flex flex-col overflow-y-auto"
    class:right-0={mobileMenuOpen}
    class:right-[-100%]={!mobileMenuOpen}
  >
    <div class="flex justify-between items-center p-4 border-b border-gray-100">
      <a href={logoHref} class="text-xl font-bold text-{primaryColor}">{logoText}</a>
      <button 
        class="text-3xl text-{textColor} w-10 h-10 flex items-center justify-center focus:outline-none" 
        on:click={() => mobileMenuOpen = false}
        aria-label="Close mobile menu"
      >×</button>
    </div>
    
    <nav class="p-4">
      <ul class="list-none p-0 m-0">
        {#each menuItems as item}
          <li class="my-2 relative">
            <a 
              href={item.href} 
              class="block py-2 text-{textColor} text-lg font-medium hover:text-{primaryColor} transition-colors duration-200"
              aria-current={$page.url.pathname === item.href || ($page.url.pathname !== '/' && $page.url.pathname.startsWith(item.href)) ? 'page' : undefined}
            >{item.label}</a>
            
            {#if $page.url.pathname === item.href || ($page.url.pathname !== '/' && $page.url.pathname.startsWith(item.href))}
              <span class="absolute left-[-1rem] top-1/2 transform -translate-y-1/2 w-1 h-5 bg-{primaryColor} rounded"></span>
            {/if}
          </li>
        {/each}
      </ul>
    </nav>
  </div>
</div>

<style>
  @media (max-width: 768px) {
    /* Hide existing navigation on mobile */
    :global(header nav), 
    :global(.site-nav),
    :global(nav:not(#mobile-menu nav)) {
      display: none !important;
    }
  }
</style>
